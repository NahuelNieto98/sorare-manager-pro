import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { getUserCards } from "@/lib/services/card.service";

export async function GET() {
  const session = await auth();

  if (!session?.user?.email) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  const cards = await getUserCards(session.user.email);

  return NextResponse.json(cards);
}
