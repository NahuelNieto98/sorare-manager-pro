"use client";

import { useState } from "react";

export default function ConnectSorarePage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <main className="min-h-screen bg-[#0F0B1F] flex items-center justify-center">
      <div className="w-full max-w-md rounded-2xl bg-[#17112F] p-8 border border-purple-900">
        <h1 className="text-3xl font-bold text-white mb-6">
          Conectar cuenta Sorare
        </h1>

        <input
          className="w-full rounded-lg bg-[#221A40] p-3 text-white mb-4"
          placeholder="Correo Sorare"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          className="w-full rounded-lg bg-[#221A40] p-3 text-white mb-6"
          placeholder="Contraseña"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button className="w-full rounded-lg bg-purple-600 py-3 font-bold text-white hover:bg-purple-500">
          Conectar
        </button>
      </div>
    </main>
  );
}
