import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/common/Header";

export default function GalleryPage() {
  return (
    <main className="min-h-screen bg-[#0F0B1F] text-white flex">
      <Sidebar />

      <section className="flex-1 p-10">
        <Header />

        <h1 className="text-3xl font-bold mb-8">Mi Galería</h1>

        <div className="rounded-2xl border border-purple-900 bg-[#1A1333] p-6">
          <div className="flex gap-4 mb-6">
            <input
              placeholder="Buscar jugador..."
              className="flex-1 rounded-xl bg-[#241A47] px-4 py-3 outline-none"
            />

            <select className="rounded-xl bg-[#241A47] px-4">
              <option>Todas las rarezas</option>
            </select>

            <select className="rounded-xl bg-[#241A47] px-4">
              <option>Todas las temporadas</option>
            </select>
          </div>

          <div className="rounded-xl border border-purple-800 overflow-hidden">
            <table className="w-full">
              <thead className="bg-[#241A47]">
                <tr>
                  <th className="text-left p-4">Jugador</th>

                  <th className="text-left p-4">Rareza</th>

                  <th className="text-left p-4">Temporada</th>

                  <th className="text-left p-4">Club</th>

                  <th className="text-left p-4">Media</th>

                  <th className="text-left p-4">Valor (€)</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <td colSpan={6} className="text-center p-12 text-zinc-500">
                    Todavía no has sincronizado tu cuenta de Sorare.
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </main>
  );
}
