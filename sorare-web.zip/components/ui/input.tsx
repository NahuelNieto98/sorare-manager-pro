"use client";

type Props = React.InputHTMLAttributes<HTMLInputElement>;

export default function Input(props: Props) {
  return (
    <input
      {...props}
      className="w-full rounded-xl border border-violet-700/30 bg-[#211A43] px-4 py-3 text-white outline-none transition focus:border-violet-500"
    />
  );
}
