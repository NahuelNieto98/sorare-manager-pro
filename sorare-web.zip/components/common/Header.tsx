"use client";

import Link from "next/link";
import { signOut } from "next-auth/react";

import {
  Bell,
  Search,
  LogOut,
  Sparkles,
  UserRound,
} from "lucide-react";


type Props = {
  sorareSlug: string | null;
  avatarUrl: string | null;
  totalCards: number;
  galleryValue: number;
};



export default function Header({
  sorareSlug,
  avatarUrl,
  totalCards,
  galleryValue,
}: Props) {


  return (

    <header
      className="
      flex
      items-center
      justify-between
      gap-6
      border-b
      border-white/10
      bg-[#0F0B1F]/80
      px-8
      py-5
      backdrop-blur
      "
    >


      {/* BUSCADOR */}

      <div
        className="
        relative
        flex-1
        max-w-xl
        "
      >

        <Search
          size={19}
          className="
          absolute
          left-4
          top-1/2
          -translate-y-1/2
          text-zinc-500
          "
        />


        <input

          placeholder="Buscar jugador, club o carta..."

          className="
          w-full
          rounded-2xl
          border
          border-white/10
          bg-white/5
          py-3.5
          pl-12
          pr-5
          text-sm
          text-white
          outline-none
          placeholder:text-zinc-500
          focus:border-purple-500/60
          "

        />


      </div>





      {/* ACCIONES */}

      <div
        className="
        flex
        items-center
        gap-4
        "
      >



        {/* NOTIFICACIONES */}

        <button

          className="
          flex
          h-12
          w-12
          items-center
          justify-center
          rounded-2xl
          border
          border-white/10
          bg-white/5
          transition
          hover:bg-white/10
          "

        >

          <Bell
            size={20}
            className="text-zinc-300"
          />

        </button>





        {/* SORARE */}

        {
          sorareSlug ? (

            <div
              className="
              flex
              items-center
              gap-4
              rounded-3xl
              border
              border-green-500/20
              bg-green-500/10
              px-5
              py-3
              "
            >


              <div
                className="
                flex
                h-12
                w-12
                items-center
                justify-center
                overflow-hidden
                rounded-2xl
                bg-green-500/20
                "
              >

                {
                  avatarUrl ? (

                    <img
                      src={avatarUrl}
                      alt={sorareSlug}
                      className="
                      h-full
                      w-full
                      object-cover
                      "
                    />

                  ) : (

                    <UserRound
                      size={25}
                      className="text-green-400"
                    />

                  )
                }


              </div>



              <div>

                <p className="font-bold text-green-400">
                  Sorare Connected
                </p>


                <p className="text-sm text-white">
                  {sorareSlug}
                </p>


                <p className="text-xs text-zinc-400">
                  {totalCards} cartas · €
                  {galleryValue.toFixed(2)}
                </p>


              </div>


            </div>


          ) : (


            <Link

              href="/connect-sorare"

              className="
              flex
              items-center
              gap-2
              rounded-2xl
              bg-gradient-to-r
              from-purple-600
              to-violet-500
              px-6
              py-3
              font-bold
              text-white
              "

            >

              <Sparkles size={18}/>

              Conectar Sorare


            </Link>


          )
        }





        {/* LOGOUT */}

        <button

          onClick={() => signOut()}

          className="
          flex
          h-12
          w-12
          items-center
          justify-center
          rounded-2xl
          border
          border-red-500/20
          bg-red-500/10
          text-red-400
          transition
          hover:bg-red-500/20
          "

        >

          <LogOut size={20}/>

        </button>



      </div>


    </header>

  );
}