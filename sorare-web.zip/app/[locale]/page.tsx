import {useTranslations} from "next-intl";


export default function HomePage(){


  const t = useTranslations("market");


  return (

    <main className="
      min-h-screen
      bg-[#0D081C]
      p-10
    ">


      <h1 className="
      text-5xl
      font-bold
      text-white
      ">

        {t("title")}

      </h1>



      <p className="
      text-xl
      text-zinc-400
      mt-5
      ">

        {t("subtitle")}

      </p>




      <div className="
      mt-10
      rounded-xl
      bg-purple-900
      p-5
      text-white
      ">

        {t("top")}

      </div>



    </main>

  );

}