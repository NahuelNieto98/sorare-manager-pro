"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";

import {
  Wallet,
  Layers,
} from "lucide-react";


import StatCard from "@/components/dashboard/StatCard";
import PortfolioCard from "@/components/dashboard/PortfolioCard";
import GalleryChart from "@/components/charts/GalleryChart";
import QuickStats from "@/components/dashboard/QuickStats";
import TopCards from "@/components/dashboard/TopCards";
import MarketSummary from "@/components/dashboard/MarketSummary";
import RecentTransactions from "@/components/dashboard/RecentTransactions";
import ScoutCard from "@/components/dashboard/ScoutCard";
import SyncGalleryButton from "@/components/dashboard/SyncGalleryButton";
import SystemStatus from "@/components/dashboard/SystemStatus";



type DashboardData = {

galleryValue:number;

average:number;

totalCards:number;

totalBought:number;

totalSold:number;

profit:number;

roi:number;


scarcity:{
limited:number;
rare:number;
superRare:number;
unique:number;
};


topCards:{
playerName:string;
marketValue:number|null;
}[];


recentTransactions:{
id:string;
type:string;
playerName:string;
rarity:string;
price:number;
}[];


needsConnection?:boolean;

};





export default function DashboardPage(){


const router = useRouter();


const t =
useTranslations("dashboard");



const [data,setData] =
useState<DashboardData|null>(null);





useEffect(()=>{


fetch("/api/dashboard")

.then(res=>res.json())

.then(json=>{


if(json.needsConnection){


router.push("/connect");

return;


}



setData(json);



});


},[router]);







if(!data){


return (

<div

className="
flex
h-full
items-center
justify-center
text-2xl
text-white
"

>

{t("loading")}


</div>


);


}







return (


<div className="space-y-10">






<section

className="
relative
overflow-hidden
rounded-3xl
border
border-white/10
bg-gradient-to-br
from-[#24194d]
via-[#17132f]
to-[#0f0b1f]
p-10
shadow-2xl
"

>



<div

className="
absolute
-right-20
-top-20
h-72
w-72
rounded-full
bg-purple-500/20
blur-3xl
"

/>





<div

className="
relative
flex
flex-col
gap-8
xl:flex-row
xl:items-center
xl:justify-between
"

>




<div>



<p

className="
text-sm
font-bold
uppercase
tracking-widest
text-violet-300
"

>

Sorare Manager Pro

</p>





<h1

className="
mt-3
text-5xl
font-black
text-white
"

>

{t("heroTitle")}


</h1>





<p

className="
mt-4
max-w-xl
text-lg
text-zinc-400
"

>

{t("heroDescription")}


</p>




</div>
      <div
        className="
        flex
        flex-col
        gap-4
        "
      >


        <SyncGalleryButton />



        <div
          className="
          flex
          gap-4
          "
        >



          <div
            className="
            rounded-2xl
            border
            border-white/10
            bg-white/5
            px-5
            py-4
            "
          >


            <Wallet
              size={22}
              className="text-violet-300"
            />



            <p
              className="
              mt-2
              text-2xl
              font-black
              text-white
              "
            >

              €
              {data.galleryValue.toLocaleString(
                "es-ES",
                {
                  minimumFractionDigits:2
                }
              )}

            </p>



            <p className="text-xs text-zinc-400">

              {t("collectionValue")}

            </p>


          </div>







          <div
            className="
            rounded-2xl
            border
            border-white/10
            bg-white/5
            px-5
            py-4
            "
          >


            <Layers
              size={22}
              className="text-blue-300"
            />



            <p
              className="
              mt-2
              text-2xl
              font-black
              text-white
              "
            >

              {data.totalCards}

            </p>



            <p className="text-xs text-zinc-400">

              {t("cards")}

            </p>


          </div>




        </div>



      </div>



    </div>


  </section>







  <section

    className="
    grid
    gap-6
    xl:grid-cols-4
    "

  >



    <StatCard

      title={t("galleryValue")}

      value={`€${data.galleryValue.toFixed(2)}`}

      subtitle={`${data.totalCards} ${t("cards")}`}

    />




    <StatCard

      title={t("roi")}

      value={`${data.roi.toFixed(2)}%`}

      subtitle={t("profitability")}

    />




    <StatCard

      title={t("profit")}

      value={`€${data.profit.toFixed(2)}`}

      subtitle={t("currentResult")}

    />





    <StatCard

      title={t("essence")}

      value={data.average.toFixed(1)}

      subtitle={t("average")}

    />



  </section>







  <PortfolioCard

    galleryValue={data.galleryValue}

    profit={data.profit}

    roi={data.roi}

  />







  <section

    className="
    grid
    gap-6
    xl:grid-cols-3
    "

  >



    <div className="xl:col-span-2">

      <GalleryChart />

    </div>





    <QuickStats

      totalCards={data.totalCards}

      average={data.average}

    />



  </section>







  <section

    className="
    grid
    gap-6
    xl:grid-cols-2
    "

  >



    <TopCards

      cards={data.topCards}

    />



    <MarketSummary

      bought={data.totalBought}

      sold={data.totalSold}

    />



  </section>








  <section

    className="
    grid
    gap-6
    xl:grid-cols-2
    "

  >



    <RecentTransactions

      transactions={data.recentTransactions}

    />




    <ScoutCard />



  </section>






  <SystemStatus />





</div>


);


}